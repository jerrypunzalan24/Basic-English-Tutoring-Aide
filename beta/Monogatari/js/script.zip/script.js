// Define the messages used in the game.
var messages = {
	"Help": {
		"Title": "Help",
		"Subtitle": "Some useful Links",
		"Message": "<p><a href='http://monogatari.hyuchia.com/documentation/'>Documentation</a> - Everything you need to know.</p><p><a href='http://monogatari.hyuchia.com/demo/'>Demo</a> - A simple Demo.</p>"
	}
}

// Define the notifications used in the game
var notifications = {
	"Welcome": {
		title: "Welcome",
		body: "This is the Monogatari VN Engine",
		icon: ""
	}
}

// Define the Particles JS Configurations used in the game
var particles = {

}

// Define the music used in the game.
var music = {

}

// Define the voice files used in the game.
var voice = {

}

// Define the sounds used in the game.
var sound = {

}

// Define the videos used in the game.
var videos = {

}

// Define the images used in the game.
var images = {

}

// Define the backgrounds for each scene.
var scenes = {
	"classroom":"classroom.jpg",
	"supermarket":"supermarket.jpg"
}

// Define the Characters
var characters = {
	"sachi": {
		"Name": "Sachi",
		"Color": "#5bcaff",
		"Directory":"Sachi",
		"Images":{

			"Normal":"sachinormal.png",
			"Happy":"sachi.png"
		}
	},
	"henrik":{
		"Name":"Henrik",
		"Color":"#5bcaff",
		"Directory":"Henrik",
		"Images":{
			"Normal":"henrik_normal.png",
			"Happy":"henrik_smile.png"
		}
	}
}

var script = {
	// The game starts here.

	"Start": [

		"scene classroom",
		"show sachi Normal center with fadeIn",
		"notify Welcome",

		"sachi Hi {{player.Name}} Welcome to Basic English Tutoring Aid!",

		{"Choice": {
			"Dialog": "sachi Which lesson are we going to study today?",
			"Possessive": {
				"Text": "Possessive Nouns",
				"Do": "jump Possessive"
			},
			"Pronouns": {
				"Text": "Pronouns",
				"Do": "jump Pronouns"
			},
            "BeVerbs": {
                "Text": "Be Verbs",
                "Do": "jump BeVerbs"
            },
            "ActionVerbs": {
                "Text": "Action Verbs",
                "Do": "jump ActionVerbs"
            },
            "Adjectives":{
                "Text": "Adjectives",
                "Do": "jump Adjectives"
            }
		}
		}
	],
	// Possessive Noun Questions
	"Possessive": [

		"sachi Possessive nouns are used to indicate ownership ",
		"sachi Possessive nouns usually are formed by adding an apostrophe (') and s.",
		"sachi Examples: John's Book, Kerry's Car, Grandma's Mirror",
		"jump QuestionPossessiveOne",
	],

	"QuestionPossessiveOne":[
		"Now for question #1",
		{"Choice":{
			"Dialog":"sachi Which of the following is correct?",
			"IncorrectPossessiveOne":{
				"Text":"Liandrys Torment costs around 3100 gold",
				"Do":"jump IncorrectPossessiveOne"
			}
			,
			"CorrectPossessiveOne":{
				"Text":"Rakan and Xayah's teamwork is perfect",
				"Do":"jump CorrectPossessiveOne"
			}
		}
		}

	],
	"IncorrectPossessiveOne":[
		"show sachi Normal center",
		"Incorrect",
		"jump QuestionPossessiveTwo"
	]
	,
	"CorrectPossessiveOne":[
		"show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionPossessiveTwo"
	],
	"QuestionPossessiveTwo":[
		"Now for question #2",
		{"Choice":{
			"Dialog":"sachi Which of the following iscorrect?",
			"IncorrectPossessiveTwo":{
				"Text":"This bow belongs to Vaynes",
				"Do":"jump IncorrectPossessiveTwo"
			}
			,
			"CorrectPossessiveTwo":{
				"Text":"Ms. Ahri's Star Guardian skin will be available this week.",
				"Do":"jump CorrectPossessiveTwo"
			},
			"IncorrectPossessiveThree":{
				"Text":"This bow belongs to Vaynes",
				"Do":"jump IncorrectPossessiveTwo"
			}
		}
		}
	],
	"IncorrectPossessiveTwo":[
		"show sachi Normal center",
		"Incorrect",
		"jump QuestionPossessiveThree"
	]
	,
	"CorrectPossessiveTwo":[
		"show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionPossessiveThree"
	],
	"QuestionPossessiveThree":[
		"Now for question #3",
		{
			"Choice":{
				"Dialog" : "sachi Which of the following is correct?",
				"IncorrectPossessiveThree":{
					"Text":"Mrs. Smiths husband often gives her flowers",
					"Do":"jump IncorrectPossessiveThree"
				},
				"CorrectPossessiveThree":{
					"Text":"Mrs. Smith's husband often gives her flowers",
					"Do":"jump CorrectPossessiveThree"
				}
			}
		}
	]
	,
	"IncorrectPossessiveThree":[
		"show sachi Normal center",
		"Incorrect",
		"jump QuestionPossessiveFour"
	]
	,
	"CorrectPossessiveThree":[
		"show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionPossessiveFour"
	],
	"QuestionPossessiveFour":[

		"Now for question #4",
		{
			"Choice":{
				"Dialog" : "sachi Which of the following is correct?",
				"IncorrectPossessiveFour":{
					"Text":"When the childs toy broke, I fixed them.",
					"Do":"jump IncorrectPossessiveFour"
				},
				"CorrectPossessiveFour":{
					"Text":"When the child's toy broke, I fixed them.",
					"Do":"jump CorrectPossessiveFour"
				}
			}
		}
	]
	,
	"IncorrectPossessiveFour":[
		"show sachi Normal center",
		"Incorrect",
		"jump PossessiveComplete"
	]
	,
	"CorrectPossessiveFour":[
		"show sachi Happy center",
		"Correct!",
        "add_score",
		"jump PossessiveComplete"
	],
	"PossessiveComplete":[
		"show sachi Happy center",
		"finish_possessive",
		"Congratulations for finishing this topic. I hope you learn something",
	]
	,
	//End Possessive Nouns Questions
    //Start Pronouns Questions
	"Pronouns": [
		"sachi Pronouns takes the place of a noun. ",
        "sachi Here are some examples of Pronouns: He, She, It, They, I, You, etc.",
		"sachi Example: Mary is one of the heads of the ToJi Corporation. Becomes: She is one of the heads of the ToJi Corporation.",
		"Mary, Mr. James, and Tom researched and invented a drug for cancer treatment. Becomes: They researched and invented a drug for cancer treatment.",
		"jump QuestionPronounsOne"

	],

	"QuestionPronounsOne":[
		"Now for question #1",
		{"Choice":
		 {"Dialog": "sachi What is the pronoun in the sentence: Joe studies at UE, he is a college student.",
		  "Incorrect":{
			  "Text":"Joe",
			  "Do":"jump IncorrectPronounsOne"
		  },
		  "Correct":{
			  "Text":"He",
			  "Do": "jump CorrectPronounsOne"
		  }
		 }
		}
	]
	,
	"CorrectPronounsOne":[
		"show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionPronounsTwo"
	],

	"IncorrectPronounsOne":[
		"show sachi Normal center",
		"Incorrect",
		"jump QuestionPronounsTwo"
	],
    
	"QuestionPronounsTwo":[
		"Now for question #2",
		{"Choice":
		 {"Dialog": "sachi What is the pronoun in the sentence: Jake wants to eat cake, his favorite food.",
		  "Incorrect":{
			  "Text":"Jake",
			  "Do":"jump IncorrectPronounsTwo"
		  },
		  "Correct":{
			  "Text":"His",
			  "Do": "jump CorrectPronounsTwo"
		  }
		 }
		}
	]
	,
	"CorrectPronounsTwo":[
		"show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionPronounsThree"
	],

	"IncorrectPronounsTwo":[
		"show sachi Normal center",
		"Incorrect",
		"jump QuestionPronounsThree"
	],
	"QuestionPronounsThree":[
		"Now for question #3",
		{"Choice":
		 {"Dialog": "sachi What is the pronoun in the sentence: Sarah and Steve are outside, they are playing tennis.",
		  "Correct":{
			  "Text":"They",
			  "Do":"jump CorrectPronounsThree"
		  },
		  "Incorrect":{
			  "Text":"Sarah and Steve",
			  "Do": "jump IncorrectPronounsThree"
		  }
		 }
		}
	]
	,
	"CorrectPronounsThree":[
		"show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionPronounsFour"
	],

	"IncorrectPronounsThree":[
		"show sachi Normal center",
		"Incorrect",
		"jump QuestionPronounsFour"
	],
	"QuestionPronounsFour":[
		"Now for question #4",
		{"Choice":
		 {"Dialog": "sachi What is the pronoun in the sentence: John and I are studying. We have an exam tomorrow.",
		  "Correct":{
			  "Text":"We",
			  "Do":"jump CorrectPronounsFour"
		  },
		  "Incorrect":{
			  "Text":"John and I",
			  "Do": "jump IncorrectPronounsFour"
		  }
		 }
		}
	],
	"CorrectPronounsFour":[
		"show sachi Happy center",
		"Correct!",
        "add_score",
		"jump PronounsComplete"
	],

	"IncorrectPronounsFour":[
		"show sachi Normal center",
		"Incorrect",
		"jump PronounsComplete"
	],
	"PronounsComplete":[
		"show sachi Happy center",
		"finish_pronouns",
		"Congratulations for finishing this topic. I hope you learn something",
	],
	//End Pronouns Questions
    //Start Be Verbs Questions
    "BeVerbs":[
        "sachi 'Be' Verbs show action or a state of being",
        "sachi Sarah <i>goes</i> to school. School is her place to rest. She <i>likes</i> her friends at school. She <i>feels</i> relaxed. At school, she <i>learns</i> new things.",
        "sachi 'Be' Verbs must match the subject. Examples: I <i>am</i> alone. They <i>are</i> walking together.",
        "sachi 'Be' Verbs are follwed by a 'not' to form a negative sentence. Examples: I <i>am not</i> alone. They <i>are not</i> walking together.",
        "sachi 'Be' Verbs are the first word in questions. Examples: <i>Am</i> I alone? <i>Are</i> they walking together?",
        "jump QuestionBeVerbsOne"
    ],
    "QuestionBeVerbsOne":[
        "Now for question #1",
		{"Choice":
		 {"Dialog": "sachi Choose the correct verb to complete the sentence: She _____ sleeping right now.",
		  "Correct":{
			  "Text":"Is",
			  "Do":"jump CorrectBeVerbsOne"
		  },
		  "Incorrect":{
			  "Text":"Was",
			  "Do": "jump IncorrectBeVerbsOne"
		  }
		 }
		}
    ],
    "CorrectBeVerbsOne":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionBeVerbsTwo"
    ],
    "IncorrectBeVerbsOne":[
        "show sachi Normal center",
		"Incorrect!",
		"jump QuestionBeVerbsTwo"
    ],
    "QuestionBeVerbsTwo":[
        "Now for question #2",
		{"Choice":
		 {"Dialog": "sachi Choose the correct verb to complete the sentence: Have you ever _____ to New York?",
		  "Incorrect":{
			  "Text":"Was",
			  "Do":"jump IncorrectBeVerbsTwo"
		  },
		  "Correct":{
			  "Text":"Been",
			  "Do": "jump CorrectBeVerbsTwo"
		  }
		 }
		}
    ],
    "CorrectBeVerbsTwo":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionBeVerbsThree"
    ],
    "IncorrectBeVerbsTwo":[
        "show sachi Normal center",
		"Incorrect!",
		"jump QuestionBeVerbsThree"
    ],
    "QuestionBeVerbsThree":[
        "Now for question #3",
		{"Choice":
		 {"Dialog": "sachi Choose the correct verb to complete the sentence: _____ you ready?",
		  "Incorrect":{
			  "Text":"Is",
			  "Do":"jump IncorrectBeVerbsThree"
		  },
		  "Correct":{
			  "Text":"Are",
			  "Do": "jump CorrectBeVerbsThree"
		  }
		 }
		}
    ],
    "CorrectBeVerbsThree":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionBeVerbsFour"
    ],
    "IncorrectBeVerbsThree":[
        "show sachi Normal center",
		"Incorrect!",
		"jump QuestionBeVerbsFour"
    ],
    "QuestionBeVerbsFour":[
        "Now for question #4",
		{"Choice":
		 {"Dialog": "sachi Choose the correct verb to complete the sentence: Henry _____ not coming.",
		  "Correct":{
			  "Text":"Is",
			  "Do":"jump CorrectBeVerbsFour"
		  },
		  "Incorrect":{
			  "Text":"Am",
			  "Do": "jump IncorrectBeVerbsFour"
		  }
		 }
		}
    ],
    "CorrectBeVerbsFour":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump BeVerbsComplete"
    ],
    "IncorrectBeVerbsFour":[
        "show sachi Normal center",
		"Incorrect!",
		"jump BeVerbsComplete"
    ],
	"BeVerbsComplete":[
		"show sachi Happy center",
		"finish_beverbs",
		"Congratulations for finishing this topic. I hope you learn something"
	],
    //End Be Verbs Questions
    //Start Action Verbs Questions
    "ActionVerbs":[
        "sachi Action Verbs name a physical or mental action",
        "sachi Cats <i>meow</i> loudly. (physical)",
        "sachi Students <i>learn</i> new material. (abstract)",
        "sachi Action Verbs can be transitive or intransitive. Transitive verbs <i>transfer</i> their action to a <b>direct object</b>. Intransitive verbs have nothing to transfer their action to.",
        "sachi Transitive: The actress <i>wiped</i> the <b>tears</b> from her eyes. (Wiped what? Wiped tears.)",
        "sachi Intransitive: The windshield wipers <i>wiped</i> across the windshield. (Wiped what? Nothing.)",
        "jump QuestionActionVerbsOne"
    ],
    "QuestionActionVerbsOne":[
        "Now for question #1",
		{"Choice":
		 {"Dialog": "sachi Choose the action verb in the sentence: The mermaid swam away.",
		  "Incorrect":{
			  "Text":"Mermaid",
			  "Do":"jump IncorrectActionVerbsOne"
		  },
		  "Correct":{
			  "Text":"Swam",
			  "Do": "jump CorrectActionVerbsOne"
		  },
          "Incorrect":{
              "Text": "Away",
              "Do": "jump IncorrectActionVerbsOne"
          }
		 }
		}
    ],
    "CorrectActionVerbsOne":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionActionVerbsTwo"
    ],
    "IncorrectActionVerbsOne":[
        "show sachi Normal center",
		"Incorrect!",
		"jump QuestionActionVerbsTwo"
    ],
    "QuestionActionVerbsTwo":[
        "Now for question #2",
		{"Choice":
		 {"Dialog": "sachi Choose the action verb in the sentence: She pushed the yellow button.",
		  "Incorrect":{
			  "Text":"Button",
			  "Do":"jump IncorrectActionVerbsTwo"
		  },
		  "Correct":{
			  "Text":"Pushed",
			  "Do": "jump CorrectActionVerbsTwo"
		  },
          "Incorrect":{
			  "Text":"Yellow",
			  "Do":"jump IncorrectActionVerbsTwo"
		  }
		 }
		}
    ],
    "CorrectActionVerbsTwo":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionActionVerbsThree"
    ],
    "IncorrectActionVerbsTwo":[
        "show sachi Normal center",
		"Incorrect!",
		"jump QuestionActionVerbsThree"
    ],
    "QuestionActionVerbsThree":[
        "Now for question #3",
		{"Choice":
		 {"Dialog": "sachi Choose the action verb in the sentence: The wind blew the leaves.",
		  "Incorrect":{
			  "Text":"Leaves",
			  "Do":"jump IncorrectActionVerbsThree"
		  },
          "Incorrect":{
			  "Text":"Wind",
			  "Do":"jump IncorrectActionVerbsThree"
		  },
		  "Correct":{
			  "Text":"Blew",
			  "Do": "jump CorrectActionVerbsThree"
		  }
		 }
		}
    ],
    "CorrectActionVerbsThree":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionActionVerbsFour"
    ],
    "IncorrectActionVerbsThree":[
        "show sachi Normal center",
		"Incorrect!",
		"jump QuestionActionVerbsFour"
    ],
    "QuestionActionVerbsFour":[
        "Now for question #4",
		{"Choice":
		 {"Dialog": "sachi Choose the action verb in the sentence: Henry holds a purple crayon.",
		  "Correct":{
			  "Text":"Holds",
			  "Do":"jump CorrectActionVerbsFour"
		  },
		  "Incorrect":{
			  "Text":"Crayon",
			  "Do": "jump IncorrectActionVerbsFour"
		  },
		  "Incorrect":{
			  "Text":"A",
			  "Do": "jump IncorrectActionVerbsFour"
		  }
		 }
		}
    ],
    "CorrectActionVerbsFour":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump ActionVerbsComplete"
    ],
    "IncorrectActionVerbsFour":[
        "show sachi Normal center",
		"Incorrect!",
		"jump ActionVerbsComplete"
    ],
	"ActionVerbsComplete":[
		"show sachi Happy center",
		"finish_actionverbs",
		"Congratulations for finishing this topic. I hope you learn something"
	],
    //End Action Verbs Questions
    //Start Adjectives Questions
    "Adjectives":[
        "sachi An adjective is a word which modifies a noun or pronoun.",
        "sachi He's got a <i>beautiful</i> car.",
        "sachi <i>Beautiful</i> is an adjective modifying <b>car</b>.",
        "sachi Adjectives may come <i>before</i>  a <b>noun</b>.",
        "sachi He found a <i>nice</i> <b>job</b>.",
        "sachi Adjectives may also come after certain <b>verbs</b> like <b>be</b>, <b>feel</b>, <b>seem</b>, <b>look</b>.",
        "sachi He <b>is</b> <i>intelligent</i>. I <b>feel</b> <i>happy</i>. She <b>seems</b> <i>unhappy</i>. They <b>look</b> <i>fantastic</i>.",
        "jump QuestionAdjectivesOne"
    ],
    "QuestionAdjectivesOne":[
        "Now for question #1",
		{"Choice":
		 {"Dialog": "sachi Choose the adjective in the sentence: Playing on the computer is a favorite pastime of mine.",
		  "Incorrect":{
			  "Text":"Playing",
			  "Do":"jump IncorrectAdjectivesOne"
		  },
		  "Correct":{
			  "Text":"Favorite",
			  "Do": "jump CorrectAdjectivesOne"
		  }
		 }
		}
    ],
    "CorrectAdjectivesOne":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionAdjectivesTwo"
    ],
    "IncorrectAdjectivesOne":[
        "show sachi Normal center",
		"Incorrect!",
		"jump QuestionAdjectivesTwo"
    ],
    "QuestionAdjectivesTwo":[
        "Now for question #2",
		{"Choice":
		 {"Dialog": "sachi Choose the adjective in the sentence: She pushed the yellow button.",
		  "Incorrect":{
			  "Text":"Button",
			  "Do":"jump IncorrectAdjectivesTwo"
		  },
		  "Correct":{
			  "Text":"Yellow",
			  "Do": "jump CorrectAdjectivesTwo"
		  }
		  }
		 }
    ],
    "CorrectAdjectivesTwo":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionAdjectivesThree"
    ],
    "IncorrectAdjectivesTwo":[
        "show sachi Normal center",
		"Incorrect!",
		"jump QuestionAdjectivesThree"
    ],
    "QuestionAdjectivesThree":[
        "Now for question #3",
		{"Choice":
		 {"Dialog": "sachi Choose the adjective in the sentence: The little girl I was telling you about is sitting over there.",
		  "Incorrect":{
			  "Text":"Over",
			  "Do":"jump IncorrectAdjectivesThree"
		  },
		  "Correct":{
			  "Text":"Little",
			  "Do": "jump CorrectAdjectivesThree"
		  }
		 }
		}
    ],
    "CorrectAdjectivesThree":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump QuestionAdjectivesFour"
    ],
    "IncorrectAdjectivesThree":[
        "show sachi Normal center",
		"Incorrect!",
		"jump QuestionAdjectivesFour"
    ],
    "QuestionAdjectivesFour":[
        "Now for question #4",
		{"Choice":
		 {"Dialog": "sachi Choose the adjective in the sentence: I enjoy listening to loud music.",
		  "Correct":{
			  "Text":"Loud",
			  "Do":"jump CorrectAdjectivesFour"
		  },
		  "Incorrect":{
			  "Text":"Enjoy",
			  "Do": "jump IncorrectAdjectivesFour"
		  }
		 }
		}
    ],
    "CorrectAdjectivesFour":[
        "show sachi Happy center",
		"Correct!",
        "add_score",
		"jump AdjectivesComplete"
    ],
    "IncorrectAdjectivesFour":[
        "show sachi Normal center",
		"Incorrect!",
		"jump AdjectivesComplete"
    ],
	"AdjectivesComplete":[
		"show sachi Happy center",
		"finish_adjectives",
		"Congratulations for finishing this topic. I hope you learn something"
	],
    // End Adjectives Questions
	"Start1":[
		"scene supermarket",
		"show henrik Normal center with fadeIn",
		"notify Welcome",
	]
}